# Knot & Craft — Website README

## Folder Structure

```
rugsite/
├── index.html              ← Homepage
├── css/
│   └── style.css           ← All styles (design system + components)
├── js/
│   └── main.js             ← All JavaScript (nav, lightbox, forms, etc.)
├── images/                 ← Put your real rug photos here
│   ├── hero/               ← Hero section images (landscape format)
│   ├── gallery/            ← Gallery rug images (portrait preferred)
│   └── og-image.jpg        ← Social preview image (1200×630)
└── pages/
    ├── gallery.html        ← Full gallery with filter
    ├── order.html          ← Custom order form
    └── contact.html        ← Contact form + FAQ

```

---

## Adding Real Rug Photos

Replace the SVG placeholders with real images like this:

**In gallery-item:**
```html
<article class="gallery-item" data-src="images/gallery/rug-01.jpg">
  <img class="rug-img" src="images/gallery/rug-01.jpg" alt="Abstract terracotta rug, 120×160 cm">
  ...
</article>
```

**Recommended image specs:**
- Format: JPG or WebP
- Resolution: 1200px on the long side minimum
- Gallery portraits: ~800×1100px
- Hero images: ~800×1000px
- File size: aim for under 300KB (use squoosh.app to optimise)

---

## How to Deploy

### Option A — Netlify (recommended, free)

1. Go to https://netlify.com and create a free account
2. Drag your entire `rugsite/` folder onto the Netlify dashboard
3. Your site is live in seconds at a `.netlify.app` URL
4. To add your own domain: Site settings → Domain management → Add custom domain

### Option B — GitHub Pages (free)

1. Create a free GitHub account at https://github.com
2. Create a new repository called `knotandcraft`
3. Upload all files (maintain the folder structure)
4. Go to Settings → Pages → Source: main branch → Save
5. Site goes live at `https://yourusername.github.io/knotandcraft`

### Option C — Any Web Host (Hostinger, SiteGround, etc.)

1. Access your hosting control panel
2. Open File Manager or connect via FTP (FileZilla is free)
3. Upload all files to the `public_html` folder
4. Your site is live at your domain

### Custom Domain Setup (after any of the above)

1. Buy a domain at Namecheap, Porkbun, or TransIP
2. Point DNS to your host (A record or CNAME — your host provides the values)
3. Add the domain in your host's control panel
4. SSL/HTTPS is usually automatic (Let's Encrypt)

---

## Making the Forms Actually Work

The forms currently show a toast message (demo mode).
To receive real emails, integrate one of these free options:

### Formspree (easiest, free tier available)
1. Sign up at https://formspree.io
2. Create a form and get your endpoint URL
3. Replace `<form data-form="order">` with:
   ```html
   <form action="https://formspree.io/f/YOUR_ID" method="POST">
   ```
4. Remove the JavaScript form intercept in main.js (or keep both)

### Netlify Forms (free if using Netlify)
Add `netlify` attribute to your form tags:
```html
<form name="order" netlify>
```

---

## 💡 Ideas to Improve the Site

### Phase 1 — Quick wins
- [ ] Add real rug photography (biggest impact on conversions)
- [ ] Connect forms to Formspree or Netlify Forms
- [ ] Add Google Analytics or Plausible for visitor tracking
- [ ] Add a WhatsApp chat button (great for Dutch market)
- [ ] Add an Instagram feed embed (Behold.so is free)

### Phase 2 — Trust & conversion
- [ ] Add a "Customer reviews" section with photos of rugs in customer homes
- [ ] Add a "Behind the process" video (phone footage of tufting works great)
- [ ] Add a before/after slider: client image → finished rug
- [ ] Create a "Rug Care" page (builds trust, helps with SEO)
- [ ] Add a FAQ accordion section on the order page

### Phase 3 — SEO & growth
- [ ] Add proper meta tags and Open Graph images for social sharing
- [ ] Write blog posts: "How to style a custom rug", "Choosing the right rug size"
- [ ] Add schema markup (Product, LocalBusiness) for Google
- [ ] Submit sitemap to Google Search Console
- [ ] Add alt text to all real images (accessibility + SEO)

### Phase 4 — E-commerce (when ready)
- [ ] Integrate Stripe for payments (Stripe Checkout is simple to add)
- [ ] Or use Shopify's Buy Button (embed on your existing site)
- [ ] Add a deposit system: 50% upfront, 50% on completion
- [ ] Add a gift voucher product

### Tech improvements
- [ ] Add WebP format images with JPG fallback for faster loading
- [ ] Add a `<link rel="preload">` for above-the-fold images
- [ ] Add a service worker for offline support
- [ ] Set up lazy loading: `<img loading="lazy" ...>`

---

## Design Customisation

All colours are in CSS variables at the top of `style.css`:

```css
:root {
  --cream:      #F5F0E8;   /* Page background */
  --espresso:   #2C1F14;   /* Main text, dark buttons */
  --terracotta: #C8624A;   /* Accent colour — change this to match your brand */
  --sand:       #D4B896;   /* Subtle accents */
}
```

Change `--terracotta` to match your brand colour.

---

Built with semantic HTML, vanilla CSS, and vanilla JS — no build tools needed.
