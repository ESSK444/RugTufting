/* ============================================================
   KNOT & CRAFT — Main JavaScript
   Handles: nav scroll, mobile menu, lightbox, form submit,
            drag-drop upload, intersection observer animations
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  // ── STICKY NAV ──────────────────────────────────────────
  const nav = document.querySelector('.nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });
  }

  // ── MOBILE MENU ──────────────────────────────────────────
  const toggle = document.querySelector('.nav-toggle');
  const links  = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      const open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open);
      // Animate hamburger to X
      const spans = toggle.querySelectorAll('span');
      if (open) {
        spans[0].style.transform = 'translateY(6.5px) rotate(45deg)';
        spans[1].style.opacity = '0';
        spans[2].style.transform = 'translateY(-6.5px) rotate(-45deg)';
      } else {
        spans.forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
      }
    });
    // Close menu on link click
    links.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        links.classList.remove('open');
        const spans = toggle.querySelectorAll('span');
        spans.forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
      });
    });
  }

  // ── FADE-UP ANIMATIONS ──────────────────────────────────
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        // Stagger sibling elements for a cascade effect
        const siblings = entry.target.parentElement.querySelectorAll('.fade-up');
        siblings.forEach((el, idx) => {
          setTimeout(() => el.classList.add('visible'), idx * 80);
        });
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));

  // ── LIGHTBOX ────────────────────────────────────────────
  const lightbox    = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');

  if (lightbox && lightboxImg) {
    // Open lightbox on gallery item click
    document.querySelectorAll('.gallery-item[data-src]').forEach(item => {
      item.addEventListener('click', () => {
        // In production replace with real src; here we use the SVG data or placeholder
        const src = item.getAttribute('data-src');
        const svg = item.querySelector('svg');
        if (svg) {
          // Render the SVG as the lightbox image using a data URL
          const svgData = encodeURIComponent(svg.outerHTML);
          lightboxImg.src = `data:image/svg+xml,${svgData}`;
        } else if (src) {
          lightboxImg.src = src;
        }
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
      });
    });

    // Close lightbox
    const closeBtn = document.querySelector('.lightbox-close');
    const closeLightbox = () => {
      lightbox.classList.remove('active');
      document.body.style.overflow = '';
    };

    if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });
  }

  // ── UPLOAD DRAG & DROP ──────────────────────────────────
  const uploadZone = document.querySelector('.upload-zone');
  if (uploadZone) {
    const input    = uploadZone.querySelector('input[type="file"]');
    const label    = uploadZone.querySelector('p');
    const preview  = document.createElement('img');
    preview.style.cssText = 'max-width:100%;max-height:160px;border-radius:4px;margin-top:12px;object-fit:contain;';

    ['dragenter','dragover'].forEach(evt => {
      uploadZone.addEventListener(evt, e => {
        e.preventDefault();
        uploadZone.classList.add('drag-over');
      });
    });

    ['dragleave','drop'].forEach(evt => {
      uploadZone.addEventListener(evt, e => {
        e.preventDefault();
        uploadZone.classList.remove('drag-over');
      });
    });

    uploadZone.addEventListener('drop', e => {
      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith('image/')) handleFile(file);
    });

    if (input) {
      input.addEventListener('change', () => {
        if (input.files[0]) handleFile(input.files[0]);
      });
    }

    function handleFile(file) {
      const reader = new FileReader();
      reader.onload = e => {
        label.innerHTML = `<strong>${file.name}</strong> uploaded`;
        if (!uploadZone.contains(preview)) uploadZone.appendChild(preview);
        preview.src = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }

  // ── CONTACT & ORDER FORMS ───────────────────────────────
  document.querySelectorAll('form[data-form]').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const type = form.getAttribute('data-form');
      const msg = type === 'order'
        ? '✦ Request received — we\'ll be in touch within 48 hours!'
        : '✦ Message sent — thank you for reaching out!';
      showToast(msg);
      form.reset();
      // Reset upload preview if present
      const uploadLabel = form.querySelector('.upload-zone p');
      if (uploadLabel) uploadLabel.innerHTML = '<strong>Drop your image here</strong><br>or click to browse';
      const preview = form.querySelector('.upload-zone img');
      if (preview) preview.remove();
    });
  });

  // ── TOAST NOTIFICATION ──────────────────────────────────
  function showToast(msg) {
    let toast = document.querySelector('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 4000);
  }

  // ── SMOOTH SCROLL for anchor links ──────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', e => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

});
